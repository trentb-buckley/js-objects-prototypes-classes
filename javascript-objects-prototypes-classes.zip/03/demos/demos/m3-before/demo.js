'use strict'; 
(function() {

  let person = {
    name: {
      first: 'Jim',
      last: 'Cooper'
    },
    age: 29
  };

})();